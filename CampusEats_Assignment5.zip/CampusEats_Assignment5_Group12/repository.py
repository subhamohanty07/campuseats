from threading import RLock


class OrderRepository:
    """Small in-memory repository with an atomic idempotency index."""

    def __init__(self):
        self._data = {}
        self._keys = {}
        self._lock = RLock()

    def insert_once(self, order):
        with self._lock:
            previous = self._keys.get(order.idem_key)
            if previous is not None:
                return self._data[previous], False
            self._data[order.order_id] = order
            self._keys[order.idem_key] = order.order_id
            return order, True

    def find(self, order_id):
        return self._data.get(order_id)

    def all(self, status=None):
        rows = list(self._data.values())
        if status is not None:
            rows = [row for row in rows if row.status == status]
        return rows

    def remove(self, order_id):
        with self._lock:
            row = self._data.pop(order_id, None)
            if row:
                self._keys.pop(row.idem_key, None)

    def reset(self):
        with self._lock:
            self._data.clear()
            self._keys.clear()
