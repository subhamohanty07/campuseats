import gzip
import io
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))
import app


AUTH = {"Authorization": "Bearer group12-test"}


def request(method, url, payload=None, headers=None, query=""):
    raw = json.dumps(payload).encode() if payload is not None else b""
    environ = {
        "REQUEST_METHOD": method,
        "PATH_INFO": url,
        "QUERY_STRING": query,
        "CONTENT_LENGTH": str(len(raw)),
        "wsgi.input": io.BytesIO(raw),
        "REMOTE_ADDR": "127.0.0.1",
    }

    for key, value in (headers or {}).items():
        environ["HTTP_" + key.upper().replace("-", "_")] = value

    meta = {}

    def start(status, response_headers):
        meta["status"] = status
        meta["headers"] = dict(response_headers)

    body = b"".join(app.application(environ, start))
    if meta["headers"].get("Content-Encoding") == "gzip":
        body = gzip.decompress(body)
    meta["body"] = json.loads(body) if body else None
    return meta


def new_order(key="group12-key", address="Hostel Block C"):
    return request(
        "POST", "/orders",
        {
            "customerId": "student-12",
            "items": [{"menuItemId": "meal-7", "quantity": 2}],
            "deliveryAddress": address,
        },
        AUTH | {"Idempotency-Key": key},
    )


def reset():
    app.store.reset()
    app._buckets.clear()


def test_create_has_location_and_etag():
    reset()
    result = new_order()
    assert result["status"].startswith("201")
    assert result["headers"]["Location"].startswith("/orders/")
    assert "ETag" in result["headers"]
    assert result["headers"]["Cache-Control"] == "no-store"


def test_same_key_reuses_order():
    reset()
    first = new_order("same-key")
    second = new_order("same-key")
    assert first["body"]["id"] == second["body"]["id"]
    assert len(app.store.all()) == 1


def test_conditional_get():
    reset()
    made = new_order("etag-read")
    oid = made["body"]["id"]
    tag = made["headers"]["ETag"]

    cached = request("GET", f"/orders/{oid}", headers=AUTH | {"If-None-Match": tag})
    assert cached["status"].startswith("304")
    assert cached["body"] is None


def test_if_match_protects_patch_and_delete():
    reset()
    made = new_order("etag-write")
    oid = made["body"]["id"]
    tag = made["headers"]["ETag"]

    stale = request(
        "PATCH", f"/orders/{oid}", {"deliveryAddress": "Room 404"},
        AUTH | {"If-Match": '"old-tag"'},
    )
    assert stale["status"].startswith("412")

    updated = request(
        "PATCH", f"/orders/{oid}", {"deliveryAddress": "Room 404"},
        AUTH | {"If-Match": tag},
    )
    assert updated["status"].startswith("200")
    fresh_tag = updated["headers"]["ETag"]

    deleted = request(
        "DELETE", f"/orders/{oid}", headers=AUTH | {"If-Match": fresh_tag}
    )
    assert deleted["status"].startswith("204")


def test_query_filter_sort_page():
    reset()
    for i in range(3):
        new_order(f"page-{i}", f"Address {i}")

    result = request(
        "GET", "/orders", headers=AUTH,
        query="page=1&pageSize=2&sort=desc"
    )
    assert result["status"].startswith("200")
    assert result["body"]["total"] == 3
    assert len(result["body"]["orders"]) == 2


def test_bad_requests_and_auth():
    reset()
    missing_auth = request("GET", "/orders")
    assert missing_auth["status"].startswith("401")

    malformed = request(
        "POST", "/orders", {"customerId": "student-12"},
        AUTH | {"Idempotency-Key": "bad"},
    )
    assert malformed["status"].startswith("400")

    unsupported = request(
        "GET", "/orders", headers=AUTH | {"Accept": "application/xml"}
    )
    assert unsupported["status"].startswith("406")


def test_options_and_override():
    reset()
    opts = request("OPTIONS", "/orders")
    assert opts["status"].startswith("204")
    assert opts["headers"]["Allow"] == "GET, POST, OPTIONS"

    made = new_order("override")
    oid = made["body"]["id"]
    tag = made["headers"]["ETag"]
    patched = request(
        "POST", f"/orders/{oid}",
        {"deliveryAddress": "Override Room"},
        AUTH | {"X-HTTP-Method-Override": "PATCH", "If-Match": tag},
    )
    assert patched["status"].startswith("200")


def test_cancellation_states():
    reset()
    made = new_order("cancel")
    oid = made["body"]["id"]

    first = request(
        "POST", f"/orders/{oid}/cancellation",
        {"reason": "Schedule changed"}, AUTH
    )
    assert first["status"].startswith("202")

    again = request(
        "POST", f"/orders/{oid}/cancellation",
        {"reason": "Repeat"}, AUTH
    )
    assert again["status"].startswith("409")

    app.store.find(oid).status = "COMPLETED"
    rejected = request(
        "POST", f"/orders/{oid}/cancellation",
        {"reason": "Too late"}, AUTH
    )
    assert rejected["status"].startswith("422")


def test_rate_limit_and_gzip():
    reset()
    for i in range(50):
        request("GET", "/orders", headers={"Authorization": "Bearer rate12"})
    blocked = request("GET", "/orders", headers={"Authorization": "Bearer rate12"})
    assert blocked["status"].startswith("429")
    assert blocked["headers"]["Retry-After"]

    reset()
    for i in range(6):
        new_order(f"gzip-{i}", "A long delivery address used to create a larger JSON response.")
    large = request(
        "GET", "/orders",
        headers=AUTH | {"Accept-Encoding": "gzip"},
    )
    assert large["status"].startswith("200")
    assert large["headers"].get("Content-Encoding") == "gzip"
