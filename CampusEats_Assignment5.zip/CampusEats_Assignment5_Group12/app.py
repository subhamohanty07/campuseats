import os
import random
import time
from collections import defaultdict
from urllib import error, request
import json

from entities import Order
from http_helpers import etag_for, problem, read_json, respond
from repository import OrderRepository


store = OrderRepository()
RATE_LIMIT = 50
RATE_WINDOW = 50
_buckets = defaultdict(list)

VALID_STATES = {
    "PAYMENT_PENDING", "CONFIRMED", "CANCELLATION_REQUESTED", "CANCELLED", "COMPLETED"
}


def valid_order(data):
    if not isinstance(data, dict):
        raise ValueError("Order payload must be a JSON object.")

    for name in ("customerId", "items", "deliveryAddress"):
        if name not in data:
            raise ValueError(f"Missing required field: {name}.")

    if not isinstance(data["customerId"], str) or not data["customerId"].strip():
        raise ValueError("customerId must be a non-empty string.")
    if not isinstance(data["deliveryAddress"], str) or not data["deliveryAddress"].strip():
        raise ValueError("deliveryAddress must be a non-empty string.")
    if not isinstance(data["items"], list) or not data["items"]:
        raise ValueError("items must be a non-empty array.")

    for item in data["items"]:
        if not isinstance(item, dict) or not isinstance(item.get("menuItemId"), str):
            raise ValueError("Every item needs a string menuItemId.")
        if not isinstance(item.get("quantity"), int) or item["quantity"] < 1:
            raise ValueError("Every item quantity must be an integer of at least 1.")


def valid_patch(data):
    if not isinstance(data, dict) or set(data) != {"deliveryAddress"}:
        raise ValueError("Patch payload must contain only deliveryAddress.")
    if not isinstance(data["deliveryAddress"], str) or not data["deliveryAddress"].strip():
        raise ValueError("deliveryAddress must be a non-empty string.")


def auth_ok(environ):
    value = environ.get("HTTP_AUTHORIZATION", "")
    return value.startswith("Bearer ") and bool(value[7:].strip())


def rate_check(environ):
    identity = environ.get("HTTP_AUTHORIZATION") or environ.get(
        "REMOTE_ADDR", "anonymous"
    )
    now = time.time()
    history = _buckets[identity]
    history[:] = [stamp for stamp in history if stamp > now - RATE_WINDOW]

    if len(history) >= RATE_LIMIT:
        wait = max(1, int(history[0] + RATE_WINDOW - now))
        return False, {
            "X-RateLimit-Limit": str(RATE_LIMIT),
            "X-RateLimit-Remaining": "0",
            "Retry-After": str(wait),
        }

    history.append(now)
    return True, {
        "X-RateLimit-Limit": str(RATE_LIMIT),
        "X-RateLimit-Remaining": str(RATE_LIMIT - len(history)),
    }


def fail(start_response, environ, status, title, detail, limits=None, extra=None):
    return respond(
        start_response, environ, status,
        problem(status, title, detail), limits, extra
    )


def payment_attempt(order):
    """Optional external payment call; repeated attempts reuse the same key."""
    base = os.getenv("PAYMENTS_URL")
    if not base:
        return None

    body = json.dumps({
        "orderId": order.order_id,
        "amount": len(order.items) * 100,
    }).encode()
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": order.idem_key,
    }

    for attempt in range(3):
        try:
            req = request.Request(
                base.rstrip("/") + "/payments",
                data=body,
                headers=headers,
                method="POST",
            )
            with request.urlopen(req, timeout=2) as result:
                if 200 <= result.status < 300:
                    payload = json.loads(result.read() or b"{}")
                    return payload.get("id", "payment-accepted")
                return None
        except error.HTTPError as exc:
            if 400 <= exc.code < 500:
                return None
        except (error.URLError, TimeoutError, OSError):
            pass

        if attempt < 2:
            time.sleep(0.12 * (2 ** attempt) + random.uniform(0, 0.08))

    return None


def options_reply(start_response, environ, path):
    if path.rstrip("/") == "/orders":
        allow = "GET, POST, OPTIONS"
    elif path.startswith("/orders/") and path.count("/") == 2:
        allow = "GET, PATCH, DELETE, OPTIONS"
    elif path.startswith("/orders/") and path.rstrip("/").split("/")[-1] in {"cancel", "cancellation"}:
        allow = "POST, OPTIONS"
    else:
        allow = "GET, POST, PATCH, DELETE, OPTIONS"

    return respond(
        start_response, environ, 204, None,
        {"X-RateLimit-Limit": str(RATE_LIMIT),
         "X-RateLimit-Remaining": str(RATE_LIMIT)},
        {"Allow": allow},
    )


def application(environ, start_response):
    method = environ.get("REQUEST_METHOD", "GET").upper()
    path = environ.get("PATH_INFO", "")
    override = environ.get("HTTP_X_HTTP_METHOD_OVERRIDE", "").upper()

    if method == "POST" and override in {"PATCH", "DELETE", "PUT"}:
        method = override

    if method == "OPTIONS":
        return options_reply(start_response, environ, path)

    accept = environ.get("HTTP_ACCEPT", "*/*")
    if "*/*" not in accept and "application/json" not in accept:
        return fail(
            start_response, environ, 406, "Not acceptable",
            "This service responds only with application/json."
        )

    allowed, limits = rate_check(environ)
    if not allowed:
        return fail(
            start_response, environ, 429, "Rate limit exceeded",
            "Retry after the supplied Retry-After interval.", limits
        )

    if not auth_ok(environ):
        return fail(
            start_response, environ, 401, "Unauthorized",
            "Authorization: Bearer <token> is required.",
            limits, {"WWW-Authenticate": "Bearer"}
        )

    try:
        # Collection operations
        if path.rstrip("/") == "/orders":
            if method == "POST":
                return create_order(start_response, environ, limits)
            if method == "GET":
                return list_orders(start_response, environ, limits)

        # Member/sub-resource operations
        bits = [part for part in path.strip("/").split("/") if part]
        if len(bits) >= 2 and bits[0] == "orders":
            row = store.find(bits[1])
            if row is None:
                return fail(
                    start_response, environ, 404, "Order not found",
                    "No order exists with that id.", limits
                )

            if len(bits) == 2:
                if method == "GET":
                    return get_order(start_response, environ, limits, row)
                if method == "PATCH":
                    return patch_order(start_response, environ, limits, row)
                if method == "DELETE":
                    return delete_order(start_response, environ, limits, row)

            if len(bits) == 3 and bits[2] in {"cancel", "cancellation"} and method == "POST":
                return cancel_order(start_response, environ, limits, row)

        return fail(
            start_response, environ, 404, "Not found",
            "No endpoint matches this URL.", limits
        )
    except Exception:
        return fail(
            start_response, environ, 503, "Service unavailable",
            "The service could not complete the request safely.", limits
        )


def create_order(start_response, environ, limits):
    key = environ.get("HTTP_IDEMPOTENCY_KEY")
    if not key:
        return fail(
            start_response, environ, 400, "Missing Idempotency-Key",
            "An Idempotency-Key header is required.", limits
        )

    try:
        body = read_json(environ)
        valid_order(body)
    except ValueError as exc:
        return fail(
            start_response, environ, 400, "Malformed order", str(exc), limits
        )

    order, first_time = store.insert_once(
        Order(body["customerId"], body["items"], body["deliveryAddress"], key)
    )

    if first_time:
        payment = payment_attempt(order)
        if payment:
            order.payment_ref = payment
            order.status = "CONFIRMED"

    return respond(
        start_response, environ, 201, order.public(), limits,
        {
            "Location": f"/orders/{order.order_id}",
            "Cache-Control": "no-store",
            "ETag": etag_for(order),
        },
    )


def list_orders(start_response, environ, limits):
    from urllib.parse import parse_qs

    query = parse_qs(environ.get("QUERY_STRING", ""))
    status = query.get("status", [None])[0]
    if status not in ({None} | VALID_STATES):
        return fail(
            start_response, environ, 400, "Invalid status",
            "status is not a recognised order status.", limits
        )

    try:
        page = int(query.get("page", ["1"])[0])
        page_size = int(query.get("pageSize", ["20"])[0])
    except ValueError:
        return fail(
            start_response, environ, 400, "Invalid pagination",
            "page and pageSize must be integers.", limits
        )

    if page < 1 or not 1 <= page_size <= 100:
        return fail(
            start_response, environ, 400, "Invalid pagination",
            "page must be positive and pageSize must be between 1 and 100.",
            limits
        )

    order_by = query.get("sort", ["asc"])[0].lower()
    if order_by not in {"asc", "desc"}:
        return fail(
            start_response, environ, 400, "Invalid sort",
            "sort must be asc or desc.", limits
        )

    rows = sorted(
        store.all(status),
        key=lambda item: item.created_at,
        reverse=order_by == "desc",
    )
    start = (page - 1) * page_size
    page_rows = rows[start:start + page_size]

    return respond(
        start_response, environ, 200,
        {
            "orders": [row.public() for row in page_rows],
            "page": page,
            "pageSize": page_size,
            "total": len(rows),
        },
        limits,
        {"Cache-Control": "private, max-age=30"},
    )


def get_order(start_response, environ, limits, row):
    tag = etag_for(row)
    base = {"ETag": tag, "Cache-Control": "private, max-age=60"}

    if environ.get("HTTP_IF_NONE_MATCH") == tag:
        return respond(start_response, environ, 304, None, limits, base)

    return respond(start_response, environ, 200, row.public(), limits, base)


def patch_order(start_response, environ, limits, row):
    tag = etag_for(row)
    if environ.get("HTTP_IF_MATCH") != tag:
        return fail(
            start_response, environ, 412, "Precondition failed",
            "If-Match does not match the current ETag.", limits,
            {"ETag": tag}
        )

    try:
        body = read_json(environ)
        valid_patch(body)
    except ValueError as exc:
        return fail(
            start_response, environ, 400, "Malformed patch", str(exc), limits
        )

    row.delivery_address = body["deliveryAddress"]

    return respond(
        start_response, environ, 200, row.public(), limits,
        {"ETag": etag_for(row), "Cache-Control": "no-store"},
    )


def delete_order(start_response, environ, limits, row):
    tag = etag_for(row)
    if environ.get("HTTP_IF_MATCH") != tag:
        return fail(
            start_response, environ, 412, "Precondition failed",
            "If-Match does not match the current ETag.", limits,
            {"ETag": tag}
        )

    store.remove(row.order_id)
    return respond(
        start_response, environ, 204, None, limits,
        {"Cache-Control": "no-store"},
    )


def cancel_order(start_response, environ, limits, row):
    try:
        body = read_json(environ)
        if not isinstance(body, dict):
            raise ValueError("Cancellation body must be a JSON object.")
        if "reason" in body and not isinstance(body["reason"], str):
            raise ValueError("reason must be a string.")
    except ValueError as exc:
        return fail(
            start_response, environ, 400, "Malformed cancellation",
            str(exc), limits
        )

    if row.status in {"CANCELLATION_REQUESTED", "CANCELLED"}:
        return fail(
            start_response, environ, 409, "Cancellation already requested",
            "The order is already in cancellation flow.", limits
        )

    if row.status not in {"PAYMENT_PENDING", "CONFIRMED"}:
        return fail(
            start_response, environ, 422, "Order cannot be cancelled",
            "Only pending or confirmed orders may be cancelled.", limits
        )

    row.status = "CANCELLATION_REQUESTED"
    return respond(
        start_response, environ, 202, row.public(), limits,
        {"ETag": etag_for(row), "Cache-Control": "no-store"},
    )


if __name__ == "__main__":
    from wsgiref.simple_server import make_server

    print("CampusEats HTTP service: http://127.0.0.1:8001")
    make_server("127.0.0.1", 8001, application).serve_forever()
