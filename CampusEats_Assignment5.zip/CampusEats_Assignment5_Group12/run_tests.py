import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tests"))
import test_api


def main():
    cases = [
        getattr(test_api, name)
        for name in sorted(dir(test_api))
        if name.startswith("test_") and callable(getattr(test_api, name))
    ]

    passed = failed = 0
    started = time.perf_counter()
    print(f"CampusEats Assignment 5 | Group 12 | {len(cases)} checks")

    for case in cases:
        try:
            case()
            print(f"PASS  {case.__name__}")
            passed += 1
        except Exception as exc:
            print(f"FAIL  {case.__name__}: {exc}")
            failed += 1

    elapsed = time.perf_counter() - started
    print(f"\nSummary: {passed} passed / {failed} failed | {elapsed:.3f}s")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
