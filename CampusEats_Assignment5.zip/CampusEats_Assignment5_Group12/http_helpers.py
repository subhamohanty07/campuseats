import gzip
import hashlib
import json


STATUS_TEXT = {
    200: "OK", 201: "Created", 202: "Accepted", 204: "No Content",
    304: "Not Modified", 400: "Bad Request", 401: "Unauthorized",
    404: "Not Found", 406: "Not Acceptable", 409: "Conflict",
    412: "Precondition Failed", 422: "Unprocessable Content",
    429: "Too Many Requests", 503: "Service Unavailable",
}


def etag_for(order):
    canonical = json.dumps(
        order.public(), sort_keys=True, separators=(",", ":")
    ).encode()
    return '"' + hashlib.sha256(canonical).hexdigest()[:16] + '"'


def problem(status, title, detail):
    return {
        "type": "about:blank",
        "title": title,
        "status": status,
        "detail": detail,
    }


def read_json(environ):
    try:
        size = int(environ.get("CONTENT_LENGTH") or 0)
        raw = environ["wsgi.input"].read(size) if size else b""
        return json.loads(raw or b"null")
    except (ValueError, json.JSONDecodeError):
        raise ValueError("Request body is not valid JSON.")


def common_headers(environ, limits=None, extra=None):
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": environ.get("HTTP_ORIGIN", "*"),
        "Access-Control-Allow-Headers": (
            "Authorization, Content-Type, Idempotency-Key, If-None-Match, "
            "If-Match, X-HTTP-Method-Override, Accept, Accept-Encoding"
        ),
        "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
        "Access-Control-Expose-Headers": (
            "Location, ETag, X-RateLimit-Limit, X-RateLimit-Remaining, "
            "Retry-After, Content-Encoding"
        ),
        "Vary": "Accept, Accept-Encoding, Origin",
        "X-Content-Type-Options": "nosniff",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    }
    if limits:
        headers.update(limits)
    if extra:
        headers.update(extra)
    return headers


def respond(start_response, environ, status, body=None, limits=None, extra=None):
    raw = b"" if body is None else json.dumps(
        body, separators=(",", ":")
    ).encode("utf-8")
    headers = common_headers(environ, limits, extra)

    accepts_gzip = "gzip" in environ.get("HTTP_ACCEPT_ENCODING", "")
    if body is not None and len(raw) >= 256 and accepts_gzip:
        packed = gzip.compress(raw)
        if len(packed) < len(raw):
            raw = packed
            headers["Content-Encoding"] = "gzip"

    if body is None:
        headers.pop("Content-Type", None)
    headers["Content-Length"] = str(len(raw))

    start_response(
        f"{status} {STATUS_TEXT.get(status, 'OK')}",
        list(headers.items()),
    )
    return [raw]
