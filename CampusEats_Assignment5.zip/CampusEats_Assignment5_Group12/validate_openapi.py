import sys

try:
    import yaml
except ImportError:
    yaml = None


def main():
    if len(sys.argv) != 2:
        print("Usage: python validate_openapi.py openapi.yaml")
        return 2

    if yaml is None:
        print("PyYAML is required for the OpenAPI preflight.")
        return 2

    with open(sys.argv[1], encoding="utf-8") as handle:
        spec = yaml.safe_load(handle)

    problems = []
    if spec.get("openapi") != "3.0.3":
        problems.append("openapi must be 3.0.3")
    if not spec.get("info") or not spec.get("paths"):
        problems.append("info and paths are required")

    verbs = {"get", "post", "put", "patch", "delete", "options"}
    for path, item in spec.get("paths", {}).items():
        for verb, operation in item.items():
            if verb.lower() not in verbs:
                continue
            if not operation.get("responses"):
                problems.append(f"{verb.upper()} {path}: missing responses")

    if problems:
        print("OpenAPI preflight failed:")
        print("\n".join(" - " + p for p in problems))
        return 1

    print("OpenAPI 3.0.3 preflight passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
