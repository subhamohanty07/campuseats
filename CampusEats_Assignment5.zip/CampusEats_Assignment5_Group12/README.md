# CampusEats HTTP Service · Group 12

A compact, restructured implementation for **CS543 Web Services — Assignment 5**.

## Team

| Role | Name | Roll No. |
|---|---|---|
| Group Leader | Subham Kumar Mohanty | 20252651057 |
| Member | Harsh N Shende | 20252651023 |
| Member | Abhishek Jadhao | 20252651003 |
| Member | Mahi Verma | 20252651032 |
| Member | Rishabh Mishra | 20252651041 |

## What changed in this version

This submission uses a different internal layout and coding style from the supplied
archive:

- order data lives in `entities.py`
- persistence/idempotency is isolated in `repository.py`
- HTTP serialization, ETags and common headers are in `http_helpers.py`
- endpoint behaviour is grouped into small handler functions in `app.py`
- tests are collected under `tests/test_api.py`
- documentation is condensed into a new notes layout
- a separate HTML overview is included for quick inspection

The external API behaviour remains aligned with the Assignment 5 requirements:
HTTP method semantics, query parameters, OPTIONS/Allow, method override,
content negotiation, authorization headers, ETags, conditional requests,
idempotency, rate limiting, CORS, gzip and the required status codes.

## Run

```text
python app.py
```

Service:

```text
http://127.0.0.1:8001
```

Run the automated checks in another terminal:

```text
python run_tests.py
```

Expected result:

```text
9 passed / 0 failed
```

OpenAPI preflight:

```text
python validate_openapi.py openapi.yaml
```

## Main routes

```text
GET     /orders
POST    /orders
OPTIONS /orders

GET     /orders/{orderId}
PATCH   /orders/{orderId}
DELETE  /orders/{orderId}
OPTIONS /orders/{orderId}

POST    /orders/{orderId}/cancellation
```

`POST /orders` requires `Idempotency-Key`. Updates/deletes require `If-Match`.
Single-order reads expose `ETag` and support `If-None-Match`.

## Files

```text
CampusEats_Assignment5_Group12/
├── app.py
├── entities.py
├── repository.py
├── http_helpers.py
├── openapi.yaml
├── NOTES.md
├── curl-transcript.txt
├── SERVICE_GUIDE.html
├── run_tests.py
├── validate_openapi.py
└── tests/
    └── test_api.py
```
