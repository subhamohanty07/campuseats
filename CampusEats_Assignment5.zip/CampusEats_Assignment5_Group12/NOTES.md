# CampusEats · HTTP Methods & Headers
### Assignment 5 submission notes — Group 12

> **Team ID:** 12  
> **Team Leader:** Subham Kumar Mohanty — `20252651057`  
> **Members:** Harsh N Shende (`20252651023`), Abhishek Jadhao (`20252651003`), Mahi Verma (`20252651032`), Rishabh Mishra (`20252651041`)

---

## 1. Endpoint map

| Operation | Route | Success | Safe | Idempotent |
|---|---|---:|:---:|:---:|
| Browse orders | `GET /orders?status=&sort=&page=&pageSize=` | 200 | Yes | Yes |
| View one order | `GET /orders/{id}` | 200 | Yes | Yes |
| Create order | `POST /orders` | 201 | No | Key-protected |
| Edit address | `PATCH /orders/{id}` | 200 | No | Yes |
| Remove order | `DELETE /orders/{id}` | 204 | No | Yes |
| Ask for cancellation | `POST /orders/{id}/cancellation` | 202 | No | No |
| Discover methods | `OPTIONS ...` | 204 | Yes | Yes |

For clients that cannot send `PATCH` or `DELETE`, the service accepts `POST` plus
`X-HTTP-Method-Override` as the documented compatibility path.

The list endpoint keeps filters, sorting and pagination in the query string. The
cancellation operation is represented as a sub-resource rather than an RPC-style
URL.

---

## 2. Header matrix

| Route | Request headers | Important response headers |
|---|---|---|
| `GET /orders` | `Authorization`, optional `Accept`, optional `Accept-Encoding` | `Cache-Control`, rate-limit fields, CORS/security fields, optional `Content-Encoding` |
| `POST /orders` | `Authorization`, `Content-Type`, **`Idempotency-Key`** | `Location`, `ETag`, `Cache-Control: no-store` |
| `GET /orders/{id}` | `Authorization`, optional `If-None-Match` | `ETag`, `Cache-Control: private, max-age=60` |
| `PATCH /orders/{id}` | `Authorization`, `Content-Type`, **`If-Match`** | new `ETag`, `Cache-Control: no-store` |
| `DELETE /orders/{id}` | `Authorization`, **`If-Match`** | `Cache-Control: no-store` |
| `POST /orders/{id}/cancellation` | `Authorization`, `Content-Type` | `ETag`, `Cache-Control: no-store` |
| `OPTIONS` | browser CORS preflight headers when applicable | `Allow`, CORS headers |

Every JSON response uses `application/json`. Unsupported `Accept` values produce
`406`. Missing bearer authentication produces `401`. A client that consumes its
50-request window receives `429` with `Retry-After`.

Security defaults include `X-Content-Type-Options: nosniff` and
`Strict-Transport-Security`. The development WSGI server supplies transport
metadata such as `Date` and `Server`.

---

## 3. Retry and cache rules

### Create: `Idempotency-Key`
Order creation changes state, so a lost response could tempt a client to send the
same request again. The repository stores the key beside the created order. A
repeat with that key returns the existing result instead of creating another
order or repeating the optional payment call.

### Read: `If-None-Match`
A single-order response exposes an ETag. Sending the same value through
`If-None-Match` gives `304 Not Modified` with no body.

### Write: `If-Match`
Address updates and deletion require the current ETag. A stale value returns
`412 Precondition Failed`, protecting the resource from an accidental lost
update.

### Cancellation
Cancellation is intentionally not treated as a normal update. A second request
during cancellation gives `409 Conflict`; a valid request against a state that
cannot be cancelled gives `422`.

---

## 4. Required questions

### Q1 — Three endpoints and their key headers

**A. `POST /orders` → `201 Created`**  
`Location` matters most because it tells the client where the newly assigned
order resource can be addressed.

**B. `GET /orders/{id}` → `200 OK` / `304 Not Modified`**  
`ETag` is central because the same value drives conditional reads and later
optimistic writes.

**C. `DELETE /orders/{id}` → `204 No Content`**  
`Cache-Control: no-store` prevents a mutation response from being retained as
cacheable data.

---

### Q2 — Safe and idempotent operations

**Safe:** both GET routes and the OPTIONS routes. They do not modify the stored
order state.

**Idempotent:** the GET/OPTIONS routes, address PATCH and protected DELETE.

**Neither:** `POST /orders` and the cancellation POST can change state when
repeated.

Creation is made retry-safe with `Idempotency-Key`: the first request creates the
record; a repeated request with the same key reuses that record.

---

### Q3 — ETag, 304 and 412

Example ETag:

```text
"7f0c9d31b6e8a204"
```

A conditional read:

```http
GET /orders/ord-demo123 HTTP/1.1
Host: 127.0.0.1:8001
Authorization: Bearer demo-token
If-None-Match: "7f0c9d31b6e8a204"
```

If the representation is unchanged, the response is `304 Not Modified` and has
no body. This avoids retransmitting an unchanged representation.

A stale update:

```http
PATCH /orders/ord-demo123 HTTP/1.1
Host: 127.0.0.1:8001
Authorization: Bearer demo-token
Content-Type: application/json
If-Match: "stale-version"

{"deliveryAddress":"Block D, Room 204"}
```

The service returns `412 Precondition Failed`, so an older copy cannot silently
overwrite a newer one.

---

### Q4 — 400 versus 422

**400 example**

```http
POST /orders HTTP/1.1
Host: 127.0.0.1:8001
Authorization: Bearer demo-token
Content-Type: application/json
Idempotency-Key: bad-input-12

{"customerId":"student-12"}
```

The JSON object is missing required fields, so the message is malformed for the
API contract.

**422 example**

```http
POST /orders/ord-demo123/cancellation HTTP/1.1
Host: 127.0.0.1:8001
Authorization: Bearer demo-token
Content-Type: application/json

{"reason":"No longer needed"}
```

If that order has already reached the `COMPLETED` state, the request is structurally
valid but rejected by the order's lifecycle rules.

In short: **400 = request problem; 422 = domain-state problem.**

---

### Q5 — Why can the browser show failure after a server 200?

The browser enforces the Same-Origin Policy. The API must explicitly permit the
web origin through:

```text
Access-Control-Allow-Origin
```

For a preflighted request, the server also needs appropriate
`Access-Control-Allow-Methods` and `Access-Control-Allow-Headers` values.

---

### Q6 — Cacheable response versus no-store

A single-order GET uses:

```text
Cache-Control: private, max-age=60
```

It is a read and can be reused briefly by the requesting client.

Creation, update, deletion and cancellation use:

```text
Cache-Control: no-store
```

Those responses describe state-changing operations and should not be retained by
a cache.

---

### Q7 — When would POST be preferable to GET for search?

POST can be useful when a query is too large or structurally complex for a URL,
or when putting the criteria in the URL would expose sensitive filtering data
through normal URL logging/history.

The trade-off is that GET is naturally suited to cacheable, bookmarkable and
shareable reads. Switching the search to POST loses those convenient GET
semantics unless additional application behaviour is built.

---

### Q8 — Meaning of Location

On **201 Created**, `Location` identifies the resource that was just created:

```text
Location: /orders/{new-order-id}
```

On a **3xx redirect**, `Location` identifies the URI the client should use as
the next destination.

---

## 5. Full exchange snapshot

### Request

```http
POST /orders HTTP/1.1
Host: 127.0.0.1:8001
Accept: application/json
Content-Type: application/json
Authorization: Bearer group12-demo
Idempotency-Key: group12-order-01

{"customerId":"student-12","items":[{"menuItemId":"meal-7","quantity":2}],"deliveryAddress":"Hostel Block C"}
```

### Response

```http
HTTP/1.0 201 Created
Content-Type: application/json
Location: /orders/ord-demo123
ETag: "7f0c9d31b6e8a204"
Cache-Control: no-store
X-RateLimit-Limit: 50
X-RateLimit-Remaining: 49
X-Content-Type-Options: nosniff
Strict-Transport-Security: max-age=31536000; includeSubDomains

{"id":"ord-demo123","customerId":"student-12","items":[{"menuItemId":"meal-7","quantity":2}],"deliveryAddress":"Hostel Block C","status":"PAYMENT_PENDING","createdAt":"2026-09-22T10:00:00+00:00"}
```

> The HTTP version shown here reflects the local Python WSGI development server.
> Production deployment can sit behind an HTTPS reverse proxy.

---

## 6. Submission contents

- `app.py` — HTTP routing and endpoint behaviour
- `entities.py` — order model
- `repository.py` — in-memory storage and idempotency index
- `http_helpers.py` — JSON, ETag, compression and common headers
- `openapi.yaml` — API contract
- `tests/test_api.py` — automated checks
- `run_tests.py` — dependency-light test runner
- `validate_openapi.py` — OpenAPI preflight
- `curl-transcript.txt` — verification examples
- `SERVICE_GUIDE.html` — compact browser-readable submission overview

The implementation covers the Assignment 5 requirements for methods, headers,
conditional requests, retries, CORS, rate limiting and failure responses. The
assignment brief requires the submitted NOTES file to show the Team ID and the
roll number/name of every member.
